import pygame
import random
import sys
from pathlib import Path

# --- setup ---
pygame.init()
WIDTH, HEIGHT = 640, 360
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Rock Paper Scissors")

ASSET_DIR = Path(__file__).resolve().parent

def load_img(name):
    p = ASSET_DIR / name
    if not p.exists():
        raise FileNotFoundError(f"Missing image: {name} in {ASSET_DIR}")
    img = pygame.image.load(str(p)).convert_alpha()
    return img

rock_img = load_img("rock.png.webp")
paper_img = load_img("paper.png.webp")
scissors_img = load_img("scissors.png.png")

# optional: scale images to same height
TARGET_H = 160
def scale(img):
    w, h = img.get_size()
    return pygame.transform.smoothscale(img, (int(w * TARGET_H / h), TARGET_H))

rock_img, paper_img, scissors_img = map(scale, [rock_img, paper_img, scissors_img])

choices = {
    "rock": rock_img,
    "paper": paper_img,
    "scissors": scissors_img
}
ordered = ["rock", "paper", "scissors"]

# positions for menu buttons
menu_positions = {
    "rock": (40, 160),
    "paper": (240, 160),
    "scissors": (440, 160)
}

# build rects for click detection
menu_rects = {}
for name in ordered:
    img = choices[name]
    x, y = menu_positions[name]
    rect = img.get_rect(topleft=(x, y - img.get_height() // 2))
    menu_rects[name] = rect

font = pygame.font.SysFont(None, 40)

def result_text(player, cpu):
    if player == cpu:
        return "draw"
    wins = {("rock", "scissors"), ("scissors", "paper"), ("paper", "rock")}
    return "win" if (player, cpu) in wins else "lose"

def draw_menu():
    screen.fill((15, 15, 18))
    title = font.render("Pick one", True, (230, 230, 230))
    screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 20))
    for name in ordered:
        screen.blit(choices[name], menu_rects[name].topleft)
        label = font.render(name, True, (200, 200, 200))
        lx = menu_rects[name].centerx - label.get_width() // 2
        ly = menu_rects[name].bottom + 8
        screen.blit(label, (lx, ly))
    pygame.display.update()

def draw_result(player, cpu, outcome):
    screen.fill((15, 15, 18))
    # player left, cpu right
    left_img = choices[player]
    right_img = choices[cpu]
    screen.blit(left_img, (120 - left_img.get_width() // 2, HEIGHT // 2 - left_img.get_height() // 2))
    screen.blit(right_img, (520 - right_img.get_width() // 2, HEIGHT // 2 - right_img.get_height() // 2))
    vs = font.render("vs", True, (220, 220, 220))
    screen.blit(vs, (WIDTH // 2 - vs.get_width() // 2, HEIGHT // 2 - vs.get_height() // 2))
    msg = font.render(outcome, True, (255, 255, 255))
    screen.blit(msg, (WIDTH // 2 - msg.get_width() // 2, 20))
    tip = font.render("Press SPACE to play again", True, (180, 180, 180))
    screen.blit(tip, (WIDTH // 2 - tip.get_width() // 2, HEIGHT - 50))
    pygame.display.update()

draw_menu()
state = "menu"

player_choice = None

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if state == "menu":
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                pos = pygame.mouse.get_pos()
                for name, rect in menu_rects.items():
                    if rect.collidepoint(pos):
                        player_choice = name
                        cpu_choice = random.choice(ordered)
                        outcome = result_text(player_choice, cpu_choice)
                        draw_result(player_choice, cpu_choice, outcome)
                        state = "result"
                        break
        elif state == "result":
            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                draw_menu()
                state = "menu"
